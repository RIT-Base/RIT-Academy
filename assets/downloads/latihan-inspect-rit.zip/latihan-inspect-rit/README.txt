=== LATIHAN INSPECT ELEMENT & CSS DEBUGGING - RIT ACADEMY ===

Selamat datang di tantangan menyembuhkan website rusak!

CARA MENGGUNAKAN:
1. Buka file "index.html" dengan cara klik ganda di browsermu (Chrome, Edge, Firefox, dll).
2. Perhatikan tampilan halaman:
   - Masalah 1: Kartu pengumuman teksnya menempel persis ke garis bingkai (tidak ada ruang napas).
   - Masalah 2: Gambar poster ukurannya raksasa dan bablas keluar layar sehingga halaman bisa digeser ke kanan (horizontal scroll).
3. Klik kanan pada elemen yang bermasalah -> pilih "Inspect" (atau tekan F12).
4. Di panel Styles sebelah kanan:
   - Tambahkan "padding: 16px;" pada class ".kartu-pengumuman".
   - Tambahkan "max-width: 100%; height: auto;" pada class ".poster".
5. Lihat perubahannya langsung di browsermu!
6. Setelah tampilannya rapi, buka file "style.css" di VS Code, tulis aturan CSS tersebut, lalu simpan permanen.

Selamat bereksperimen!
